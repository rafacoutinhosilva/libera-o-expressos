# Liberação dos Expressos · PortoEX

Painel de lançamento e dashboard da liberação dos expressos (Firebase Firestore + GitHub Pages).

## Arquivos

- `index.html` — o painel (Dashboard, Lançar, Registros)
- `firebase-config.js` — configuração do projeto Firebase (único arquivo a editar)
- `importar.html` — importa o histórico da planilha (85 liberações, jun–set/2026). Usar uma vez e apagar.

## Passo a passo

1. **Firebase:** pode usar o mesmo projeto do controle de pallets. Os dados ficam na coleção `expressos`, separada.
   Em Configurações do projeto > Seus apps > App da Web, copie o objeto `firebaseConfig` e cole no `firebase-config.js`.
2. **Regras do Firestore** (Firestore Database > Regras). Adicione o bloco `match /expressos/{id}` dentro das regras que já existem:

   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /expressos/{id} {
         allow read, write: if true;
       }
     }
   }
   ```

   Atenção: assim qualquer pessoa com o link consegue ler e lançar. Serve para uso interno; se precisar restringir depois, dá pra colocar login.
3. **GitHub:** crie um repositório, suba os 4 arquivos e ative em Settings > Pages > Branch `main` / pasta raiz.
4. Abra `https://SEU-USUARIO.github.io/NOME-DO-REPO/importar.html`, clique em **Importar para o Firebase** e depois apague o `importar.html` do repositório.
5. Pronto: o painel fica em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.
